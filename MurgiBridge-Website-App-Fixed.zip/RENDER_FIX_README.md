# MurgiBridge Render deployment fix

The Render log `ENOENT ... /opt/render/project/src/package.json` means the service is configured to run `npm install` in a folder named `src`, but this project has no root-level `src/package.json`.

## Correct Render settings for the API

Use the repository/archive root as the project root, and configure the API service as follows:

- **Root Directory:** `backend`
- **Runtime:** Node
- **Build Command:** `npm install`
- **Start Command:** `npm start`
- **Health Check Path:** `/health`

The backend's `package.json` is at `backend/package.json`. Do not set Root Directory to `src`.

## Recommended deployment

Push the CONTENTS of this folder to the GitHub repository root (so `render.yaml` and `backend/` are at the repository root), then create/update the Render service from the Blueprint. The included `render.yaml` already sets `rootDir: backend` and defines the PostgreSQL database.

If you are editing the existing Render service manually, open **Settings → Build & Deploy** and change Root Directory from `src` to `backend`, then save and trigger a deploy.

Set the required environment variables in Render as described in `RENDER_DEPLOYMENT.md`. Never put production secrets in GitHub or the mobile app.
