CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(32) UNIQUE,
  password_hash TEXT NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'farmer' CHECK (role IN ('farmer','buyer','seller','doctor','admin')),
  city VARCHAR(120), state VARCHAR(120), country VARCHAR(120) DEFAULT 'India',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (email IS NOT NULL OR phone IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS listings (
  id BIGSERIAL PRIMARY KEY,
  seller_id BIGINT NOT NULL REFERENCES users(id),
  title VARCHAR(180) NOT NULL,
  category VARCHAR(40) NOT NULL CHECK (category IN ('birds','chicks','feed','medicine','equipment','other')),
  breed VARCHAR(100), description TEXT,
  quantity NUMERIC(12,2) NOT NULL CHECK (quantity > 0), unit VARCHAR(20) NOT NULL DEFAULT 'kg',
  price_paise BIGINT NOT NULL CHECK (price_paise > 0), city VARCHAR(120), state VARCHAR(120),
  image_url TEXT, status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','sold','paused','removed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS listings_search_idx ON listings(status, category, created_at DESC);
CREATE TABLE IF NOT EXISTS orders (
  id BIGSERIAL PRIMARY KEY,
  buyer_id BIGINT NOT NULL REFERENCES users(id), seller_id BIGINT NOT NULL REFERENCES users(id),
  listing_id BIGINT NOT NULL REFERENCES listings(id), quantity NUMERIC(12,2) NOT NULL CHECK (quantity > 0),
  unit_price_paise BIGINT NOT NULL CHECK (unit_price_paise > 0), total_paise BIGINT NOT NULL CHECK (total_paise > 0),
  status VARCHAR(24) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','confirmed','packed','shipped','delivered','cancelled','refunded')),
  delivery_address TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS payments (
  id BIGSERIAL PRIMARY KEY, order_id BIGINT NOT NULL UNIQUE REFERENCES orders(id),
  provider_order_id VARCHAR(100) UNIQUE, provider_payment_id VARCHAR(100) UNIQUE,
  amount_paise BIGINT NOT NULL, currency VARCHAR(3) NOT NULL DEFAULT 'INR',
  status VARCHAR(20) NOT NULL DEFAULT 'created' CHECK (status IN ('created','authorized','captured','failed','refunded')),
  method VARCHAR(30), raw_payload JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS consultations (
  id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), subject VARCHAR(180) NOT NULL,
  question TEXT NOT NULL, image_url TEXT, status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open','assigned','answered','closed')),
  answer TEXT, expert_id BIGINT REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
