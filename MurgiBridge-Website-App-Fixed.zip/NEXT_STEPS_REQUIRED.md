# What is still needed to launch MurgiBridge for real

The codebase is prepared for the next integration/deployment stage, but the following cannot be completed without your service accounts and deployment access:

1. A public HTTPS API host and PostgreSQL database.
2. A strong JWT secret and production database credentials.
3. Razorpay merchant account credentials (test first; live only after KYC approval) and a configured webhook.
4. A real public privacy-policy domain and verified customer support details.
5. An SMS/OTP provider if phone verification is required.
6. An image/object-storage provider for poultry photos and consultation attachments.
7. An EAS account/project for signed Android and iOS builds.

## Still incomplete in the uploaded app UI

The app now has real API authentication, but the Buy/Sell, order creation, order tracking, consultation image uploads, admin dashboard, training and AI support screens are not yet fully wired to live service providers. Existing hard-coded sample marketplace and profile content must be removed before a public launch. The backend exposes core APIs for listings, orders, payments, consultations and admin operations, but no real-world delivery network or escrow/trust account is provisioned by this source code.

Do not accept customer funds or publish the app until the full flows have been integrated and tested end-to-end.
