# MurgiBridge 2.0

MurgiBridge is an Expo React Native app for Android and iOS with a Node.js / PostgreSQL backend. This repository contains the mobile app, backend API, web dashboard/checkout prototypes, release notes and privacy policy page.

## What is implemented in this upgrade

- Mobile sign-in and registration against the API; access tokens stored using Expo SecureStore.
- PostgreSQL schema for users, listings, orders, payments and expert consultations.
- JWT authentication, password hashing, role checks, auth rate limiting and protected API routes.
- Marketplace listing create/search/update endpoints and stock-aware order creation.
- Server-priced Razorpay orders (the client cannot choose or alter the payment amount), HMAC signature verification and raw-body webhook signature validation.
- Consultation submission and doctor/admin response endpoints.
- Admin metrics and user activation controls API.
- Docker Compose deployment for API + PostgreSQL.

## Important: deployment is required

The uploaded archive did not include a live server, PostgreSQL database, Razorpay merchant credentials, SMS/OTP provider, image-storage account or EAS project. Therefore this source upgrade is **not yet a live public service**. The marketplace screens, profile content, tracking, AI assistance, training and the separate admin HTML still contain prototype/demo behavior and need provider setup plus end-to-end integration. No fake payment success is used by the new API.

## Deploy on Render

See [`RENDER_DEPLOYMENT.md`](RENDER_DEPLOYMENT.md). A Render Blueprint is included at [`render.yaml`](render.yaml) and provisions the API plus managed PostgreSQL. Review the paid service/database plans and enter secrets in Render; never commit credentials.

## Start the backend

See [`backend/README.md`](backend/README.md). Briefly:

```bash
cd backend
cp .env.example .env
# Set POSTGRES_PASSWORD, JWT_SECRET, Razorpay test keys, webhook secret and admin credentials
# Ensure DATABASE_URL points to your PostgreSQL instance
docker compose up --build -d
```

Health check: `GET https://YOUR_API_HOST/health`.

## Configure the mobile app

Set `expo.extra.apiBaseUrl` in `app.json` to your deployed HTTPS API origin. Keep `razorpayKeyId` blank if using the API's public `keyId` response. Do not put `RAZORPAY_KEY_SECRET`, database credentials, JWT secret or webhook secret in the mobile app. Install dependencies and build with EAS (the native Razorpay SDK does not run in Expo Go):

```bash
npm install
npx expo install expo-secure-store
npx eas login
npx eas build --platform android --profile production
npx eas build --platform ios --profile production
```

The EAS project ID in `app.json` is still a placeholder and must be replaced using `npx eas init`.

## API reference

See [`backend/README.md`](backend/README.md) for endpoint list, auth requirements, Razorpay webhook setup and production checklist.

## Before real customers use it

1. Deploy API + managed PostgreSQL behind HTTPS; set strong secrets and backups.
2. Create a Razorpay merchant account, complete KYC, test checkout/webhooks/refunds with TEST keys, then request LIVE activation.
3. Connect marketplace screens to listing/order APIs; implement photo storage and delivery tracking provider.
4. Connect admin UI to authenticated admin APIs; remove hard-coded/demo data.
5. Implement verified phone OTP, account recovery, support contacts, consent, privacy/data deletion workflows and monitoring.
6. Run end-to-end tests on physical Android and iPhone devices, then complete Play Console/App Store privacy and data-safety declarations.
