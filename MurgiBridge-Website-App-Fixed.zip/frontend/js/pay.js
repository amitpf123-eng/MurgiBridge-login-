(function () {
  const amountInput = document.getElementById('amountRupees');
  const purposeInput = document.getElementById('purpose');
  const nameInput = document.getElementById('custName');
  const phoneInput = document.getElementById('custPhone');
  const payBtn = document.getElementById('payBtn');
  const statusBox = document.getElementById('statusBox');
  const displayAmount = document.getElementById('displayAmount');
  const purposeLabel = document.getElementById('purposeLabel');
  const resultCard = document.getElementById('resultCard');
  const resultLog = document.getElementById('resultLog');
  const modeBadge = document.getElementById('modeBadge');

  function fmt(n) {
    return Number(n).toLocaleString('en-IN');
  }

  function showStatus(type, msg) {
    statusBox.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  }

  function syncLabels() {
    displayAmount.textContent = fmt(amountInput.value || 0);
    purposeLabel.textContent = purposeInput.value || 'Order';
  }

  amountInput.addEventListener('input', syncLabels);
  purposeInput.addEventListener('input', syncLabels);

  document.querySelectorAll('.method').forEach((el) => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.method').forEach((m) => m.classList.remove('selected'));
      el.classList.add('selected');
      el.querySelector('input').checked = true;
    });
  });

  async function init() {
    if (window.MURGI_CONFIG.ready) await window.MURGI_CONFIG.ready;

    const key = window.MURGI_CONFIG.razorpayKeyId;
    try {
      const h = await healthCheck();
      if (h.mockMode || window.MURGI_CONFIG.mockMode) {
        modeBadge.textContent = 'MOCK';
        modeBadge.className = 'badge badge-warn';
        showStatus(
          'warn',
          'Backend connected (mock mode). Real Razorpay ke liye <code>backend/.env</code> mein keys daalo.'
        );
      } else if (h.razorpayConfigured) {
        modeBadge.textContent = (h.mode || 'test').toUpperCase();
        modeBadge.className = 'badge badge-ok';
        showStatus('success', 'Backend connected · Razorpay ready');
      } else {
        modeBadge.textContent = 'No keys';
        modeBadge.className = 'badge badge-warn';
      }
      if (!key && h.razorpayConfigured === false && !h.mockMode) {
        showStatus('warn', 'Key ID missing. Settings se set karo ya backend .env mein RAZORPAY_KEY_ID daalo.');
      }
    } catch (e) {
      modeBadge.textContent = 'Offline';
      modeBadge.className = 'badge badge-err';
      showStatus('error', e.message);
    }
  }

  init();

  payBtn.addEventListener('click', async () => {
    const rupees = Number(amountInput.value);
    if (!rupees || rupees < 1) {
      showStatus('error', 'Valid amount enter karo.');
      return;
    }

    if (window.MURGI_CONFIG.ready) await window.MURGI_CONFIG.ready;

    const method = document.querySelector('input[name="method"]:checked')?.value || 'upi';
    const amountPaise = Math.round(rupees * 100);
    const purpose = purposeInput.value || 'MurgiBridge Order';
    const key = window.MURGI_CONFIG.razorpayKeyId;

    payBtn.disabled = true;
    payBtn.textContent = 'Creating order…';
    showStatus('info', 'Backend par order create ho raha hai…');

    try {
      const order = await createOrder({
        amountPaise,
        purpose,
        method,
        customer: {
          name: nameInput.value,
          contact: phoneInput.value,
        },
      });

      // Mock order — no Razorpay popup
      if (order.mock || String(order.id).startsWith('order_mock_')) {
        const fakePayId = 'pay_mock_' + Date.now();
        const v = await verifyPayment({
          razorpay_order_id: order.id,
          razorpay_payment_id: fakePayId,
          razorpay_signature: 'mock',
        });
        showStatus(
          'success',
          `Mock payment OK · Order <strong>${order.id}</strong> · Payment <strong>${fakePayId}</strong>`
        );
        resultCard.style.display = 'block';
        resultLog.textContent = JSON.stringify({ order, verification: v }, null, 2);
        return;
      }

      if (!key) {
        showStatus(
          'error',
          'Order ban gaya lekin Razorpay Key ID nahi hai. Settings ya backend .env check karo.'
        );
        resultCard.style.display = 'block';
        resultLog.textContent = JSON.stringify(order, null, 2);
        return;
      }

      if (typeof Razorpay === 'undefined') {
        showStatus('error', 'Razorpay script load nahi hui.');
        return;
      }

      const options = {
        key,
        amount: order.amount,
        currency: order.currency || 'INR',
        name: window.MURGI_CONFIG.appName,
        description: purpose,
        order_id: order.id,
        prefill: {
          name: nameInput.value,
          contact: phoneInput.value,
        },
        theme: { color: '#166534' },
        handler: async function (response) {
          showStatus('info', 'Backend par payment verify ho rahi hai…');
          try {
            const v = await verifyPayment({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            if (v.verified) {
              showStatus(
                'success',
                `Payment successful! ID: <strong>${response.razorpay_payment_id}</strong>`
              );
            } else {
              showStatus('warn', v.message || 'Verify fail');
            }
            resultCard.style.display = 'block';
            resultLog.textContent = JSON.stringify({ response, verification: v }, null, 2);
          } catch (err) {
            showStatus('error', 'Verify failed: ' + err.message);
            resultCard.style.display = 'block';
            resultLog.textContent = JSON.stringify({ response, error: err.message }, null, 2);
          }
        },
        modal: {
          ondismiss: function () {
            showStatus('warn', 'Checkout band kiya gaya.');
          },
        },
      };

      const rzp = new Razorpay(options);
      rzp.on('payment.failed', function (resp) {
        showStatus('error', resp.error?.description || 'Payment failed');
        resultCard.style.display = 'block';
        resultLog.textContent = JSON.stringify(resp, null, 2);
      });
      rzp.open();
      showStatus('info', 'Razorpay checkout open hai…');
    } catch (err) {
      showStatus('error', err.message);
    } finally {
      payBtn.disabled = false;
      payBtn.textContent = 'Pay Securely';
    }
  });
})();
