# MurgiBridge release status

## Current source status

- Expo Android/iOS project: present; Expo SDK 52 / React Native 0.76.
- Authentication: API-backed email/phone + password login and registration; JWT stored in SecureStore.
- Backend: PostgreSQL-backed API, schema migration, role-protected endpoints.
- Razorpay: server-side order creation and signature/webhook verification implemented; requires merchant keys and deployment.
- Marketplace screens, admin HTML, delivery tracking, expert workflows, AI and training: not yet fully connected to production providers; do not advertise these as live until verified.

## Required before store submission

- [ ] Replace placeholder EAS project ID with `npx eas init`.
- [ ] Set `expo.extra.apiBaseUrl` to the deployed HTTPS API.
- [ ] Deploy PostgreSQL and API; configure backups, monitoring and secret storage.
- [ ] Complete Razorpay merchant KYC and test checkout, capture, webhook and refund flows; use LIVE credentials only after approval.
- [ ] Complete marketplace/admin/mobile end-to-end integration and test on real devices.
- [ ] Host the privacy policy at a real public URL and update `privacyPolicyUrl` (the current `.example.com` URL is a placeholder).
- [ ] Confirm camera/photo permissions and Play Console Data Safety declarations match actual behavior.
- [ ] Provide customer support contact, account deletion workflow and terms/refund policy.
- [ ] Build and test Android AAB and iOS archive with EAS; verify app signing and store metadata.

**Do not publish or collect customer payments until every required item is completed and tested.**
