import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';

const extra = Constants.expoConfig?.extra ?? {};
export const API_BASE_URL = String(extra.apiBaseUrl || extra.paymentApiUrl || '').replace(/\/$/, '');
const TOKEN_KEY = 'murgibridge_access_token';

export async function getToken() { return SecureStore.getItemAsync(TOKEN_KEY); }
export async function saveToken(token: string) { return SecureStore.setItemAsync(TOKEN_KEY, token); }
export async function clearToken() { return SecureStore.deleteItemAsync(TOKEN_KEY); }

export async function apiRequest<T = any>(path: string, options: RequestInit = {}, authenticated = true): Promise<T> {
  if (!API_BASE_URL) throw new Error('API URL is not configured. Set expo.extra.apiBaseUrl and rebuild the app.');
  const token = authenticated ? await getToken() : null;
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data as T;
}
