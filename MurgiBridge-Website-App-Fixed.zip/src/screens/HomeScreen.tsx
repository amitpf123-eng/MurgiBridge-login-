import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {
  ShoppingCart,
  TrendingUp,
  BookOpen,
  MapPin,
  Bell,
  Bot,
} from 'lucide-react-native';

export default function HomeScreen() {
  const navigation = useNavigation<any>();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Namaste Farmer 👋</Text>
          <Text style={styles.subGreeting}>MurgiBridge mein aapka swagat hai</Text>
        </View>
        <TouchableOpacity style={styles.bellBtn}>
          <Bell color="#fff" size={22} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Jaldi Se Shuru Karein</Text>
        <View style={styles.quickRow}>
          <TouchableOpacity
            style={[styles.quickCard, { backgroundColor: '#dcfce7' }]}
            onPress={() => navigation.navigate('Buy')}
          >
            <ShoppingCart color="#166534" size={28} />
            <Text style={styles.quickText}>Chooja / Feed{'\n'}Kharido</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.quickCard, { backgroundColor: '#fef3c7' }]}
            onPress={() => navigation.navigate('Sell')}
          >
            <TrendingUp color="#b45309" size={28} />
            <Text style={styles.quickText}>Murgi{'\n'}Becho</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.quickCard, { backgroundColor: '#e0e7ff' }]}
            onPress={() => navigation.navigate('Training')}
          >
            <BookOpen color="#3730a3" size={28} />
            <Text style={styles.quickText}>Training{'\n'}Lein</Text>
          </TouchableOpacity>
        </View>

        {/* Mandi Rates Preview */}
        <Text style={styles.sectionTitle}>Aaj Ke Mandi Rates</Text>
        <View style={styles.rateCard}>
          <View style={styles.rateRow}>
            <Text style={styles.rateLabel}>Broiler (Live)</Text>
            <Text style={styles.rateValue}>₹98 - 105 /kg</Text>
          </View>
          <View style={styles.rateRow}>
            <Text style={styles.rateLabel}>Layer (Culled)</Text>
            <Text style={styles.rateValue}>₹72 - 78 /kg</Text>
          </View>
          <View style={styles.rateRow}>
            <Text style={styles.rateLabel}>Desi Murgi</Text>
            <Text style={styles.rateValue}>₹180 - 220 /kg</Text>
          </View>
          <TouchableOpacity
            style={styles.viewAllBtn}
            onPress={() => navigation.navigate('Sell')}
          >
            <Text style={styles.viewAllText}>Sabhi Mandi Rates Dekhein →</Text>
          </TouchableOpacity>
        </View>

        {/* AI Help */}
        <View style={styles.aiCard}>
          <Bot color="#166534" size={32} />
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={styles.aiTitle}>24×7 AI Agent</Text>
            <Text style={styles.aiSub}>Koi bhi problem ho to turant poochhein</Text>
          </View>
          <TouchableOpacity
            style={styles.aiBtn}
            onPress={() =>
              Alert.alert('Coming soon', '24×7 AI chat will be available in a future update.')
            }
          >
            <Text style={styles.aiBtnText}>Chat</Text>
          </TouchableOpacity>
        </View>

        {/* Nearby Info */}
        <View style={styles.nearbyCard}>
          <MapPin color="#166534" size={20} />
          <Text style={styles.nearbyText}>
            Aapke paas 3 Distribution Points aur 2 Local Buyers available hain
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    backgroundColor: '#166534',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: { color: '#fff', fontSize: 20, fontWeight: '700' },
  subGreeting: { color: '#bbf7d0', fontSize: 13, marginTop: 2 },
  bellBtn: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 10,
    borderRadius: 12,
  },
  content: { padding: 16, paddingBottom: 30 },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    marginTop: 8,
  },
  quickRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  quickCard: {
    flex: 1,
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
  },
  quickText: {
    marginTop: 8,
    fontSize: 12,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'center',
  },
  rateCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
  },
  rateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  rateLabel: { fontSize: 14, color: '#475569' },
  rateValue: { fontSize: 14, fontWeight: '700', color: '#166534' },
  viewAllBtn: { marginTop: 12, alignItems: 'center' },
  viewAllText: { color: '#166534', fontWeight: '600', fontSize: 13 },
  aiCard: {
    backgroundColor: '#ecfdf5',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  aiTitle: { fontSize: 15, fontWeight: '700', color: '#166534' },
  aiSub: { fontSize: 12, color: '#4b5563', marginTop: 2 },
  aiBtn: {
    backgroundColor: '#166534',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  aiBtnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  nearbyCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  nearbyText: { flex: 1, fontSize: 13, color: '#475569' },
});
