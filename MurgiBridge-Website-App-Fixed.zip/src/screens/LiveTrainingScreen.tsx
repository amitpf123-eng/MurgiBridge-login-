import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { Video, Users, Calendar, Clock } from 'lucide-react-native';

const UPCOMING_SESSIONS = [
  {
    id: 1,
    title: 'Broiler Housing & Temperature Management',
    expert: 'Dr. Suresh Patel',
    date: '29 Oct 2026',
    time: '10:00 AM',
    language: 'Hindi',
  },
  {
    id: 2,
    title: 'Vaccination Schedule & Common Mistakes',
    expert: 'Dr. Meena Sharma',
    date: '30 Oct 2026',
    time: '3:00 PM',
    language: 'Hindi + English',
  },
  {
    id: 3,
    title: 'How to Get Best Price in Mandi',
    expert: 'Expert Rakesh Yadav',
    date: '1 Nov 2026',
    time: '11:00 AM',
    language: 'Hindi',
  },
];

export default function LiveTrainingScreen() {
  const [joined, setJoined] = useState<number | null>(null);

  const handleJoin = (id: number) => {
    setJoined(id);
    Alert.alert(
      'Session Booked!',
      'Aapko reminder notification aur SMS mil jayega. Live session start hone par link bhej diya jayega.'
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.hero}>
        <Video color="#166534" size={40} />
        <Text style={styles.heroTitle}>Live Training Sessions</Text>
        <Text style={styles.heroSub}>
          Expert aur Doctor ke saath live class join karein
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Aane Wali Sessions</Text>

      {UPCOMING_SESSIONS.map((session) => (
        <View key={session.id} style={styles.sessionCard}>
          <Text style={styles.sessionTitle}>{session.title}</Text>
          <View style={styles.metaRow}>
            <Users color="#64748b" size={14} />
            <Text style={styles.metaText}>{session.expert}</Text>
          </View>
          <View style={styles.metaRow}>
            <Calendar color="#64748b" size={14} />
            <Text style={styles.metaText}>{session.date}</Text>
            <Clock color="#64748b" size={14} style={{ marginLeft: 12 }} />
            <Text style={styles.metaText}>{session.time}</Text>
          </View>
          <Text style={styles.lang}>Language: {session.language}</Text>

          <TouchableOpacity
            style={[
              styles.joinBtn,
              joined === session.id && styles.joinedBtn,
            ]}
            onPress={() => handleJoin(session.id)}
            disabled={joined === session.id}
          >
            <Text style={styles.joinBtnText}>
              {joined === session.id ? '✓ Booked' : 'Join Live Session'}
            </Text>
          </TouchableOpacity>
        </View>
      ))}

      <TouchableOpacity
        style={styles.requestBtn}
        onPress={() =>
          Alert.alert(
            'Request Sent',
            'Aapki request expert ko bhej di gayi hai. Jaldi response milega.'
          )
        }
      >
        <Text style={styles.requestBtnText}>
          + Apna Topic Suggest Karein / Special Session Maangein
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 40 },
  hero: {
    backgroundColor: '#ecfdf5',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  heroTitle: { fontSize: 18, fontWeight: '700', color: '#166534', marginTop: 10 },
  heroSub: { fontSize: 13, color: '#4b5563', marginTop: 4, textAlign: 'center' },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
  },
  sessionCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
  },
  sessionTitle: { fontSize: 15, fontWeight: '700', color: '#1e293b', marginBottom: 8 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  metaText: { fontSize: 12, color: '#64748b' },
  lang: { fontSize: 12, color: '#166534', fontWeight: '600', marginTop: 6, marginBottom: 12 },
  joinBtn: {
    backgroundColor: '#166534',
    borderRadius: 10,
    paddingVertical: 11,
    alignItems: 'center',
  },
  joinedBtn: { backgroundColor: '#86efac' },
  joinBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  requestBtn: {
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#166534',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  requestBtnText: { color: '#166534', fontWeight: '600', fontSize: 13 },
});
