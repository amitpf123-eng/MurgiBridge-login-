import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {
  MapPin,
  Building2,
  Globe,
  Users,
  TrendingUp,
  ChevronRight,
} from 'lucide-react-native';

const MANDI_OPTIONS = [
  {
    id: 'local',
    title: 'Local Buyers / Sellers',
    subtitle: 'Aas-paas ke local kharidar',
    icon: Users,
    color: '#166534',
    bg: '#dcfce7',
    description: 'Gaon / shehar ke local traders aur retailers',
    examples: 'Local meat shops, hotels, small traders',
  },
  {
    id: 'district',
    title: 'District Mandi',
    subtitle: 'Zila level ki mandi',
    icon: MapPin,
    color: '#b45309',
    bg: '#fef3c7',
    description: 'District poultry mandi rates aur buyers',
    examples: 'District APMC, poultry market',
  },
  {
    id: 'state',
    title: 'State Mandi',
    subtitle: 'Rajya level ki badi mandi',
    icon: Building2,
    color: '#1d4ed8',
    bg: '#dbeafe',
    description: 'State ke major poultry markets',
    examples: 'State level wholesale markets',
  },
  {
    id: 'international',
    title: 'International Mandi',
    subtitle: 'Export opportunities',
    icon: Globe,
    color: '#7c3aed',
    bg: '#ede9fe',
    description: 'Export buyers aur international rates',
    examples: 'Export houses, Gulf & SE Asia buyers',
  },
];

const SAMPLE_RATES = {
  local: [
    { name: 'Local Meat Shop - Rampur', rate: '₹102/kg', distance: '3 km' },
    { name: 'Hotel Green Valley', rate: '₹108/kg', distance: '7 km' },
  ],
  district: [
    { name: 'District Poultry Mandi', rate: '₹99-104/kg', distance: '18 km' },
    { name: 'Zila APMC Yard', rate: '₹97-103/kg', distance: '22 km' },
  ],
  state: [
    { name: 'State Wholesale Market', rate: '₹96-102/kg', distance: '85 km' },
  ],
  international: [
    { name: 'Export Buyer (Gulf)', rate: '₹115-125/kg', distance: 'Export' },
    { name: 'SE Asia Trader', rate: '₹110-120/kg', distance: 'Export' },
  ],
};

export default function SellScreen() {
  const navigation = useNavigation<any>();
  const [selectedMandi, setSelectedMandi] = useState('local');

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Murgi Becho</Text>
        <Text style={styles.headerSub}>
          Local se International tak – jahan easy ho wahan bechein
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Kahan Bechna Hai?</Text>
        <Text style={styles.sectionSub}>
          Apne hisaab se sabse easy option chunein
        </Text>

        {MANDI_OPTIONS.map((item) => {
          const Icon = item.icon;
          const isSelected = selectedMandi === item.id;
          return (
            <TouchableOpacity
              key={item.id}
              style={[
                styles.mandiCard,
                isSelected && { borderColor: item.color, borderWidth: 2 },
              ]}
              onPress={() => setSelectedMandi(item.id)}
              activeOpacity={0.8}
            >
              <View style={[styles.iconBox, { backgroundColor: item.bg }]}>
                <Icon color={item.color} size={24} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.mandiTitle}>{item.title}</Text>
                <Text style={styles.mandiSub}>{item.subtitle}</Text>
                <Text style={styles.mandiDesc}>{item.description}</Text>
              </View>
              <ChevronRight color="#94a3b8" size={20} />
            </TouchableOpacity>
          );
        })}

        {/* Selected Mandi Details */}
        <View style={styles.detailCard}>
          <View style={styles.detailHeader}>
            <TrendingUp color="#166534" size={18} />
            <Text style={styles.detailTitle}>
              {MANDI_OPTIONS.find((m) => m.id === selectedMandi)?.title} – Available Options
            </Text>
          </View>

          {(SAMPLE_RATES as any)[selectedMandi].map((r: any, idx: number) => (
            <View key={idx} style={styles.rateItem}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rateName}>{r.name}</Text>
                <Text style={styles.rateDistance}>{r.distance}</Text>
              </View>
              <Text style={styles.ratePrice}>{r.rate}</Text>
            </View>
          ))}

          <TouchableOpacity
            style={styles.listBtn}
            onPress={() =>
              navigation.navigate('MandiDetail', { mandiType: selectedMandi })
            }
          >
            <Text style={styles.listBtnText}>Is Mandi mein Listing Karein</Text>
          </TouchableOpacity>
        </View>

        {/* Quick Sell Button */}
        <TouchableOpacity style={styles.quickSellBtn}>
          <Text style={styles.quickSellText}>+ Apni Murgi List Karein</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    backgroundColor: '#166534',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 18,
  },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: '700' },
  headerSub: { color: '#bbf7d0', fontSize: 13, marginTop: 4 },
  content: { padding: 16, paddingBottom: 40 },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
  },
  sectionSub: { fontSize: 13, color: '#64748b', marginBottom: 14 },
  mandiCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    gap: 12,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mandiTitle: { fontSize: 15, fontWeight: '700', color: '#1e293b' },
  mandiSub: { fontSize: 12, color: '#64748b', marginTop: 1 },
  mandiDesc: { fontSize: 11, color: '#94a3b8', marginTop: 3 },
  detailCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginTop: 10,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
  },
  detailHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  detailTitle: { fontSize: 14, fontWeight: '700', color: '#166534', flex: 1 },
  rateItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  rateName: { fontSize: 14, fontWeight: '600', color: '#1e293b' },
  rateDistance: { fontSize: 12, color: '#64748b', marginTop: 2 },
  ratePrice: { fontSize: 14, fontWeight: '700', color: '#166534' },
  listBtn: {
    backgroundColor: '#166534',
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 14,
  },
  listBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  quickSellBtn: {
    backgroundColor: '#fef3c7',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#fcd34d',
  },
  quickSellText: { color: '#b45309', fontWeight: '700', fontSize: 15 },
});
