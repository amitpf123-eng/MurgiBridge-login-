import React, { useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { apiRequest, saveToken } from '../services/api';

export default function AuthScreen({ onAuthenticated }: { onAuthenticated: () => void }) {
  const [register, setRegister] = useState(false);
  const [name, setName] = useState('');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    if (!identifier.trim() || password.length < 8 || (register && name.trim().length < 2)) {
      Alert.alert('Check your details', register ? 'Enter your name, email or phone, and a password of at least 8 characters.' : 'Enter your email/phone and password (at least 8 characters).');
      return;
    }
    setBusy(true);
    try {
      const data = register
        ? await apiRequest<{token:string}>('/auth/register', { method:'POST', body:JSON.stringify({ name, ...(identifier.includes('@') ? { email:identifier.trim() } : { phone:identifier.trim() }), password, role:'farmer' }) }, false)
        : await apiRequest<{token:string}>('/auth/login', { method:'POST', body:JSON.stringify({ identifier:identifier.trim(), password }) }, false);
      await saveToken(data.token);
      onAuthenticated();
    } catch (e:any) { Alert.alert('Unable to sign in', e.message || 'Please try again.'); }
    finally { setBusy(false); }
  };
  return <SafeAreaView style={styles.safe}><KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><View style={styles.logo}><Text style={styles.chicken}>🐓</Text></View><Text style={styles.title}>MurgiBridge</Text><Text style={styles.subtitle}>Poultry farming, connected</Text><View style={styles.card}><Text style={styles.heading}>{register?'Create your account':'Welcome back'}</Text>{register&&<TextInput style={styles.input} placeholder="Full name" value={name} onChangeText={setName} autoCapitalize="words"/>}<TextInput style={styles.input} placeholder="Email address or phone number" value={identifier} onChangeText={setIdentifier} autoCapitalize="none" keyboardType="email-address"/><TextInput style={styles.input} placeholder="Password (minimum 8 characters)" value={password} onChangeText={setPassword} secureTextEntry/><TouchableOpacity style={styles.button} onPress={submit} disabled={busy}>{busy?<ActivityIndicator color="#fff"/>:<Text style={styles.buttonText}>{register?'Create account':'Sign in'}</Text>}</TouchableOpacity><TouchableOpacity onPress={()=>setRegister(!register)} style={styles.switch}><Text style={styles.switchText}>{register?'Already registered? Sign in':'New to MurgiBridge? Create account'}</Text></TouchableOpacity></View><Text style={styles.note}>By continuing, you agree to use MurgiBridge responsibly. Keep your password private.</Text></ScrollView></KeyboardAvoidingView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#f8fafc'},content:{flexGrow:1,justifyContent:'center',padding:24},logo:{alignSelf:'center',width:76,height:76,borderRadius:24,backgroundColor:'#dcfce7',alignItems:'center',justifyContent:'center'},chicken:{fontSize:38},title:{fontSize:30,fontWeight:'800',color:'#14532d',textAlign:'center',marginTop:12},subtitle:{fontSize:14,color:'#64748b',textAlign:'center',marginBottom:28},card:{backgroundColor:'#fff',padding:20,borderRadius:18,borderWidth:1,borderColor:'#e2e8f0'},heading:{fontSize:20,fontWeight:'700',color:'#0f172a',marginBottom:18},input:{height:50,borderWidth:1,borderColor:'#cbd5e1',borderRadius:10,paddingHorizontal:14,marginBottom:12,color:'#0f172a'},button:{height:50,backgroundColor:'#166534',borderRadius:10,alignItems:'center',justifyContent:'center',marginTop:4},buttonText:{color:'#fff',fontWeight:'700',fontSize:16},switch:{padding:16,alignItems:'center'},switchText:{color:'#166534',fontWeight:'600'},note:{textAlign:'center',fontSize:12,color:'#94a3b8',marginTop:20,lineHeight:18}});
