import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Search, MapPin, Star, Truck } from 'lucide-react-native';

const CHICKEN_TYPES = [
  { id: 'broiler', name: 'Broiler', icon: '🐔' },
  { id: 'layer', name: 'Layer', icon: '🥚' },
  { id: 'desi', name: 'Desi / Country', icon: '🐓' },
  { id: 'kadaknath', name: 'Kadaknath', icon: '⚫' },
];

const SUPPLIERS = [
  {
    id: 1,
    name: 'Shree Poultry Hatchery',
    type: 'Company',
    distance: '4.2 km',
    rating: 4.7,
    products: 'Chicks, Feed, Medicine',
    delivery: 'Same Day',
  },
  {
    id: 2,
    name: 'Gramin Distribution Point',
    type: 'Distribution Point',
    distance: '1.8 km',
    rating: 4.5,
    products: 'Feed, Dawa, Equipment',
    delivery: '2-4 Hours',
  },
  {
    id: 3,
    name: 'National Chick Suppliers',
    type: 'Company',
    distance: '12 km',
    rating: 4.8,
    products: 'All Types Chicks',
    delivery: 'Next Day',
  },
];

export default function BuyScreen() {
  const [selectedType, setSelectedType] = useState('broiler');
  const navigation = useNavigation<any>();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Kharido</Text>
        <Text style={styles.headerSub}>Chooja, Feed, Dawa – Seedha Company se</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Search */}
        <View style={styles.searchBox}>
          <Search color="#94a3b8" size={18} />
          <TextInput
            placeholder="Company ya Distribution Point dhundhein..."
            placeholderTextColor="#94a3b8"
            style={styles.searchInput}
          />
        </View>

        {/* Chicken Type */}
        <Text style={styles.sectionTitle}>Murgi Ka Type Chunein</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
          {CHICKEN_TYPES.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={[
                styles.typeChip,
                selectedType === item.id && styles.typeChipActive,
              ]}
              onPress={() => setSelectedType(item.id)}
            >
              <Text style={styles.typeIcon}>{item.icon}</Text>
              <Text
                style={[
                  styles.typeText,
                  selectedType === item.id && styles.typeTextActive,
                ]}
              >
                {item.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Nearby Suppliers */}
        <Text style={styles.sectionTitle}>Aapke Paas Ke Suppliers</Text>
        {SUPPLIERS.map((s) => (
          <View key={s.id} style={styles.supplierCard}>
            <View style={styles.supplierTop}>
              <View style={{ flex: 1 }}>
                <Text style={styles.supplierName}>{s.name}</Text>
                <Text style={styles.supplierType}>{s.type}</Text>
              </View>
              <View style={styles.ratingBox}>
                <Star color="#f59e0b" size={14} fill="#f59e0b" />
                <Text style={styles.ratingText}>{s.rating}</Text>
              </View>
            </View>

            <Text style={styles.products}>{s.products}</Text>

            <View style={styles.supplierBottom}>
              <View style={styles.infoRow}>
                <MapPin color="#166534" size={14} />
                <Text style={styles.infoText}>{s.distance}</Text>
              </View>
              <View style={styles.infoRow}>
                <Truck color="#166534" size={14} />
                <Text style={styles.infoText}>{s.delivery}</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.orderBtn} onPress={() => navigation.navigate("Payment", { amount: "12,500", purpose: "Chicks + Feed Order" })}>
              <Text style={styles.orderBtnText}>Order Karein</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    backgroundColor: '#166534',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 18,
  },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: '700' },
  headerSub: { color: '#bbf7d0', fontSize: 13, marginTop: 2 },
  content: { padding: 16, paddingBottom: 30 },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  searchInput: { flex: 1, marginLeft: 10, fontSize: 14, color: '#1e293b' },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 10,
  },
  typeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  typeChipActive: {
    backgroundColor: '#166534',
    borderColor: '#166534',
  },
  typeIcon: { fontSize: 16, marginRight: 6 },
  typeText: { fontSize: 13, fontWeight: '600', color: '#475569' },
  typeTextActive: { color: '#fff' },
  supplierCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
  },
  supplierTop: { flexDirection: 'row', alignItems: 'flex-start' },
  supplierName: { fontSize: 15, fontWeight: '700', color: '#1e293b' },
  supplierType: { fontSize: 12, color: '#64748b', marginTop: 2 },
  ratingBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fef3c7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  ratingText: { fontSize: 12, fontWeight: '700', color: '#b45309' },
  products: { fontSize: 13, color: '#475569', marginTop: 8 },
  supplierBottom: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 10,
    marginBottom: 12,
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  infoText: { fontSize: 12, color: '#166534', fontWeight: '600' },
  orderBtn: {
    backgroundColor: '#166534',
    borderRadius: 10,
    paddingVertical: 11,
    alignItems: 'center',
  },
  orderBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
