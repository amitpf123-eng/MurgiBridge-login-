import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
  ActivityIndicator,
} from 'react-native';
import { useRoute } from '@react-navigation/native';
import { Stethoscope, Users, Upload, Send, Camera, X } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';

export default function ExpertOpinionScreen() {
  const route = useRoute<any>();
  const type = route.params?.type || 'doctor';
  const isDoctor = type === 'doctor';

  const [question, setQuestion] = useState('');
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const requestPermissions = async () => {
    const camera = await ImagePicker.requestCameraPermissionsAsync();
    const media = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (camera.status !== 'granted' || media.status !== 'granted') {
      Alert.alert(
        'Permission Required',
        'Camera aur gallery access chahiye photo upload karne ke liye. Settings se allow karein.'
      );
      return false;
    }
    return true;
  };

  const pickImage = async (fromCamera: boolean) => {
    const ok = await requestPermissions();
    if (!ok) return;

    setLoading(true);
    try {
      const result = fromCamera
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            quality: 0.8,
            allowsEditing: true,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            quality: 0.8,
            allowsEditing: true,
          });

      if (!result.canceled && result.assets?.[0]?.uri) {
        setImageUri(result.assets[0].uri);
      }
    } catch (e) {
      Alert.alert('Error', 'Image select nahi ho saki. Dobara try karein.');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadPress = () => {
    Alert.alert('Photo Attach Karein', 'Camera se click karein ya gallery se choose karein', [
      { text: 'Camera', onPress: () => pickImage(true) },
      { text: 'Gallery', onPress: () => pickImage(false) },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const handleSubmit = () => {
    if (!question.trim()) {
      Alert.alert('Please write your question', 'Sawal likhein taaki doctor/expert help kar saken.');
      return;
    }
    Alert.alert(
      'Submitted!',
      isDoctor
        ? 'Aapka sawal Poultry Doctor ko bhej diya gaya hai. 2-4 ghante mein reply milega.'
        : 'Aapka sawal Farm Expert ko bhej diya gaya hai. Jaldi jawab milega.',
      [{ text: 'OK' }]
    );
    setQuestion('');
    setImageUri(null);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={[styles.hero, { backgroundColor: isDoctor ? '#ecfdf5' : '#eff6ff' }]}>
        {isDoctor ? (
          <Stethoscope color="#166534" size={36} />
        ) : (
          <Users color="#1d4ed8" size={36} />
        )}
        <Text style={styles.heroTitle}>
          {isDoctor ? 'Poultry Doctor Opinion' : 'Farm Expert Suggestion'}
        </Text>
        <Text style={styles.heroSub}>
          {isDoctor
            ? 'Bimari, vaccination, treatment ke bare mein poochhein'
            : 'Farm management, feed, growth, selling strategy ke bare mein poochhein'}
        </Text>
      </View>

      <Text style={styles.label}>Apna Sawal Likhein</Text>
      <TextInput
        style={styles.textArea}
        placeholder={
          isDoctor
            ? 'Example: Mere broiler mein saans ki takleef ho rahi hai, kya karun?'
            : 'Example: 1000 birds ke liye best feed schedule kya hai?'
        }
        placeholderTextColor="#94a3b8"
        multiline
        numberOfLines={5}
        value={question}
        onChangeText={setQuestion}
        textAlignVertical="top"
      />

      {imageUri ? (
        <View style={styles.previewBox}>
          <Image source={{ uri: imageUri }} style={styles.previewImage} />
          <TouchableOpacity style={styles.removeBtn} onPress={() => setImageUri(null)}>
            <X color="#fff" size={16} />
          </TouchableOpacity>
        </View>
      ) : (
        <TouchableOpacity style={styles.uploadBtn} onPress={handleUploadPress} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#166534" />
          ) : (
            <>
              <Camera color="#166534" size={18} />
              <Text style={styles.uploadText}>Photo / Camera se Attach Karein</Text>
            </>
          )}
        </TouchableOpacity>
      )}

      <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit}>
        <Send color="#fff" size={18} />
        <Text style={styles.submitText}>Opinion Mangwaein</Text>
      </TouchableOpacity>

      <View style={styles.tipBox}>
        <Text style={styles.tipTitle}>Tips for better reply:</Text>
        <Text style={styles.tipText}>• Clear photo/video lagayein</Text>
        <Text style={styles.tipText}>• Birds ki umar aur sankhya batayein</Text>
        <Text style={styles.tipText}>• Symptoms clearly likhein</Text>
        <Text style={styles.tipText}>• Pehle se diya gaya treatment bataayein</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 40 },
  hero: {
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  heroTitle: { fontSize: 18, fontWeight: '700', color: '#0f172a', marginTop: 10 },
  heroSub: { fontSize: 13, color: '#64748b', textAlign: 'center', marginTop: 6, lineHeight: 18 },
  label: { fontSize: 14, fontWeight: '600', color: '#334155', marginBottom: 8 },
  textArea: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 14,
    fontSize: 15,
    color: '#0f172a',
    minHeight: 120,
    marginBottom: 14,
  },
  uploadBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#ecfdf5',
    borderWidth: 1,
    borderColor: '#bbf7d0',
    borderRadius: 12,
    paddingVertical: 14,
    marginBottom: 16,
  },
  uploadText: { fontSize: 14, fontWeight: '600', color: '#166534' },
  previewBox: {
    position: 'relative',
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  previewImage: { width: '100%', height: 200, borderRadius: 12 },
  removeBtn: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 16,
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#166534',
    borderRadius: 14,
    paddingVertical: 16,
  },
  submitText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  tipBox: {
    marginTop: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  tipTitle: { fontSize: 13, fontWeight: '700', color: '#334155', marginBottom: 8 },
  tipText: { fontSize: 13, color: '#64748b', marginBottom: 4 },
});
