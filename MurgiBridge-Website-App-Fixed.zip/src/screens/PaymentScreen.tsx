import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  ActivityIndicator,
  Platform,
  Linking,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import {
  CreditCard,
  Smartphone,
  Building2,
  ShieldCheck,
  CheckCircle,
  Info,
  Lock,
} from 'lucide-react-native';
import {
  amountToPaise,
  formatRupees,
  isPaymentApiConfigured,
  PAYMENT_CONFIG,
} from '../config/payment';
import {
  createRazorpayOrder,
  buildCheckoutOptions,
  verifyPaymentOnServer,
  PaymentMethod,
} from '../services/paymentService';

const PAYMENT_METHODS: {
  id: PaymentMethod;
  title: string;
  subtitle: string;
  icon: typeof Smartphone;
}[] = [
  { id: 'upi', title: 'UPI', subtitle: 'GPay, PhonePe, Paytm, BHIM', icon: Smartphone },
  { id: 'card', title: 'Credit / Debit Card', subtitle: 'Visa, Mastercard, RuPay', icon: CreditCard },
  { id: 'netbanking', title: 'Net Banking', subtitle: 'All major banks', icon: Building2 },
];

async function openRazorpayCheckout(options: Record<string, unknown>): Promise<{
  success: boolean;
  data?: any;
  error?: { code: string | number; description: string };
}> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const RazorpayCheckout = require('react-native-razorpay').default;
    const data = await RazorpayCheckout.open(options);
    return { success: true, data };
  } catch (err: any) {
    const code = err?.code ?? err?.error?.code ?? 'UNKNOWN';
    const description =
      err?.description ||
      err?.error?.description ||
      err?.message ||
      'Payment cancelled or failed';

    if (
      String(err?.message || '').includes('Cannot find module') ||
      String(err?.message || '').includes('react-native-razorpay')
    ) {
      return {
        success: false,
        error: {
          code: 'SDK_MISSING',
          description:
            'Payment SDK requires a production build (EAS). Expo Go is not supported for payments.',
        },
      };
    }

    return { success: false, error: { code, description } };
  }
}

export default function PaymentScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const orderId = String(route.params?.orderId || '');
  const amountRaw = route.params?.amount || '0';
  const purpose = route.params?.purpose || 'Chicks + Feed Order';
  const customerName = route.params?.customerName || '';
  const customerPhone = route.params?.customerPhone || '';

  const amountPaise = amountToPaise(amountRaw);
  const amountDisplay = formatRupees(amountPaise || amountToPaise('12500'));

  const [method, setMethod] = useState<PaymentMethod>('upi');
  const [upiId, setUpiId] = useState('');
  const [loading, setLoading] = useState(false);
  const [paid, setPaid] = useState(false);
  const [paymentId, setPaymentId] = useState<string | null>(null);

  const razorpayReady = isPaymentApiConfigured();

  const handlePay = async () => {
    if (!orderId) {
      Alert.alert('Order required', 'Create a real order from an available marketplace listing before making a payment.');
      return;
    }

    if (amountPaise <= 0) {
      Alert.alert('Invalid amount', 'Payment amount is not valid.');
      return;
    }

    if (method === 'upi' && upiId.trim() && !upiId.includes('@')) {
      Alert.alert('Invalid UPI ID', 'Enter a valid UPI ID (example@upi)');
      return;
    }

    if (!razorpayReady) {
      Alert.alert(
        'Payments unavailable',
        'Secure payment is not configured yet. Please try again later or contact support.'
      );
      return;
    }

    setLoading(true);
    try {
      const order = await createRazorpayOrder({
        orderId,
        purpose,
        method,
        customerName,
        customerPhone,
        customerEmail: '',
      });

      // Block mock orders in the mobile app (store safety)
      if (String(order.id).startsWith('order_demo_') || String(order.id).startsWith('order_mock_')) {
        Alert.alert(
          'Payments unavailable',
          'Payment server is in test configuration. Please try again later.'
        );
        return;
      }

      const options = buildCheckoutOptions(order, {
        orderId,
        purpose,
        method,
        customerName,
        customerPhone,
      });

      if (method === 'upi' && upiId.trim()) {
        (options as any).prefill = {
          ...(options as any).prefill,
          method: 'upi',
          vpa: upiId.trim(),
        };
      }

      const result = await openRazorpayCheckout(options);

      if (result.success && result.data) {
        const payload = {
          razorpay_payment_id: result.data.razorpay_payment_id,
          razorpay_order_id: result.data.razorpay_order_id || order.id,
          razorpay_signature: result.data.razorpay_signature || '',
        };

        const verification = await verifyPaymentOnServer(payload);
        if (!verification.verified) {
          Alert.alert('Verification pending', verification.message || 'Payment could not be verified. Do not retry immediately; contact support with your Payment ID.');
          return;
        }
        setPaymentId(payload.razorpay_payment_id);
        setPaid(true);
      } else if (result.error) {
        if (result.error.code === 0 || result.error.code === '0') {
          Alert.alert('Payment cancelled', 'You closed the payment window.');
        } else if (result.error.code === 'SDK_MISSING') {
          Alert.alert('Payment unavailable', result.error.description);
        } else {
          Alert.alert('Payment failed', result.error.description);
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Could not start payment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (paid) {
    return (
      <View style={styles.successContainer}>
        <CheckCircle color="#166534" size={64} />
        <Text style={styles.successTitle}>Payment Successful</Text>
        <Text style={styles.successSub}>
          ₹{amountDisplay} · Amount held securely until delivery confirmation
        </Text>
        {paymentId ? (
          <Text style={styles.paymentId}>Payment ID: {paymentId}</Text>
        ) : null}
        <TouchableOpacity style={styles.doneBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.doneBtnText}>Done</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.amountCard}>
        <Text style={styles.amountLabel}>Total Amount</Text>
        <Text style={styles.amountValue}>₹{amountDisplay}</Text>
        <Text style={styles.purpose}>{purpose}</Text>
      </View>

      {razorpayReady ? (
        <View style={styles.liveBadge}>
          <Lock color="#166534" size={16} />
          <Text style={styles.liveBadgeText}>
            Secured by Razorpay ·{' '}
            {PAYMENT_CONFIG.razorpayKeyId.startsWith('rzp_live') ? 'Live' : 'Test'} mode
          </Text>
        </View>
      ) : (
        <View style={styles.demoNotice}>
          <Info color="#b45309" size={18} />
          <Text style={styles.demoNoticeText}>
            Online payment is temporarily unavailable. You can browse the app; checkout will
            enable once payments are activated.
          </Text>
        </View>
      )}

      <View style={styles.escrowBox}>
        <ShieldCheck color="#166534" size={20} />
        <Text style={styles.escrowText}>
          Escrow protection: amount is released to the seller only after delivery confirmation
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Choose payment method</Text>

      {PAYMENT_METHODS.map((m) => {
        const Icon = m.icon;
        const selected = method === m.id;
        return (
          <TouchableOpacity
            key={m.id}
            style={[styles.methodCard, selected && styles.methodSelected]}
            onPress={() => setMethod(m.id)}
            disabled={loading || !razorpayReady}
          >
            <Icon color={selected ? '#166534' : '#64748b'} size={24} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={[styles.methodTitle, selected && { color: '#166534' }]}>
                {m.title}
              </Text>
              <Text style={styles.methodSub}>{m.subtitle}</Text>
            </View>
            <View style={[styles.radio, selected && styles.radioSelected]} />
          </TouchableOpacity>
        );
      })}

      {method === 'upi' && razorpayReady && (
        <View style={styles.upiBox}>
          <Text style={styles.label}>UPI ID (optional)</Text>
          <TextInput
            style={styles.input}
            placeholder="yourname@upi"
            placeholderTextColor="#94a3b8"
            value={upiId}
            onChangeText={setUpiId}
            autoCapitalize="none"
            keyboardType="email-address"
            editable={!loading}
          />
        </View>
      )}

      <TouchableOpacity
        style={[styles.payBtn, (loading || !razorpayReady) && styles.payBtnDisabled]}
        onPress={handlePay}
        disabled={loading || !razorpayReady}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.payBtnText}>
            {razorpayReady ? `Pay ₹${amountDisplay}` : 'Payment unavailable'}
          </Text>
        )}
      </TouchableOpacity>

      <Text style={styles.secureNote}>
        {Platform.OS === 'android' ? 'Android' : 'iOS'} · Payments powered by Razorpay
        {'\n'}Card details are never stored on MurgiBridge servers
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  content: { padding: 16, paddingBottom: 40 },
  amountCard: {
    backgroundColor: '#166534',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 16,
  },
  amountLabel: { color: '#bbf7d0', fontSize: 13 },
  amountValue: { color: '#fff', fontSize: 36, fontWeight: '800', marginVertical: 4 },
  purpose: { color: '#bbf7d0', fontSize: 13 },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ecfdf5',
    borderRadius: 12,
    padding: 12,
    gap: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  liveBadgeText: { flex: 1, fontSize: 13, color: '#166534', fontWeight: '600' },
  demoNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#fffbeb',
    borderRadius: 12,
    padding: 12,
    gap: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#fde68a',
  },
  demoNoticeText: {
    flex: 1,
    fontSize: 13,
    color: '#92400e',
    fontWeight: '500',
    lineHeight: 18,
  },
  escrowBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ecfdf5',
    borderRadius: 12,
    padding: 12,
    gap: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },
  escrowText: { flex: 1, fontSize: 13, color: '#166534', fontWeight: '500' },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
  },
  methodCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  methodSelected: {
    borderColor: '#166534',
    backgroundColor: '#f0fdf4',
  },
  methodTitle: { fontSize: 15, fontWeight: '600', color: '#1e293b' },
  methodSub: { fontSize: 12, color: '#64748b', marginTop: 2 },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#cbd5e1',
  },
  radioSelected: {
    borderColor: '#166534',
    backgroundColor: '#166534',
  },
  upiBox: { marginTop: 8, marginBottom: 8 },
  label: { fontSize: 13, fontWeight: '600', color: '#475569', marginBottom: 6 },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: '#0f172a',
  },
  payBtn: {
    backgroundColor: '#166534',
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 20,
    minHeight: 54,
    justifyContent: 'center',
  },
  payBtnDisabled: { opacity: 0.55 },
  payBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  secureNote: {
    textAlign: 'center',
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 14,
    lineHeight: 18,
  },
  successContainer: {
    flex: 1,
    backgroundColor: '#f8fafc',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#166534',
    marginTop: 16,
  },
  successSub: { fontSize: 14, color: '#64748b', marginTop: 6, textAlign: 'center' },
  paymentId: {
    marginTop: 12,
    fontSize: 12,
    color: '#94a3b8',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  doneBtn: {
    marginTop: 28,
    backgroundColor: '#166534',
    paddingHorizontal: 40,
    paddingVertical: 14,
    borderRadius: 12,
  },
  doneBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
