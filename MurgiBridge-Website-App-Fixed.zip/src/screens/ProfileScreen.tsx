import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Modal,
  FlatList,
  Alert,
  Linking,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {
  User,
  MapPin,
  Phone,
  Languages,
  LogOut,
  ChevronRight,
  CreditCard,
  Navigation,
  Check,
  Shield,
} from 'lucide-react-native';
import { useLanguage, LANGUAGES, LangCode } from '../context/LanguageContext';
import { clearToken } from '../services/api';

export default function ProfileScreen({ onLogout }: { onLogout?: () => void }) {
  const navigation = useNavigation<any>();
  const { lang, setLang, t } = useLanguage();
  const [langModal, setLangModal] = useState(false);

  const currentLang = LANGUAGES.find((l) => l.code === lang);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <User color="#fff" size={36} />
        </View>
        <Text style={styles.name}>Ramesh Kumar</Text>
        <Text style={styles.location}>
          <MapPin color="#bbf7d0" size={14} /> Village Rampur, District Sitapur
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Farm Details</Text>
          <Text style={styles.detail}>Farm Type: Broiler + Desi</Text>
          <Text style={styles.detail}>Capacity: 2000 Birds</Text>
          <Text style={styles.detail}>Status: Active</Text>
        </View>

        {/* Language Switcher */}
        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => setLangModal(true)}
        >
          <Languages color="#166534" size={20} />
          <View style={{ flex: 1 }}>
            <Text style={styles.menuText}>{t('language')}</Text>
            <Text style={styles.menuSub}>
              {currentLang?.native} ({currentLang?.name})
            </Text>
          </View>
          <ChevronRight color="#94a3b8" size={18} />
        </TouchableOpacity>

        {/* Payment History / Demo */}
        <TouchableOpacity
          style={styles.menuItem}
          onPress={() =>
            navigation.navigate('Payment', {
              amount: '8,750',
              purpose: 'Feed + Medicine Order',
            })
          }
        >
          <CreditCard color="#166534" size={20} />
          <Text style={styles.menuText}>Payment / Escrow</Text>
          <ChevronRight color="#94a3b8" size={18} />
        </TouchableOpacity>

        {/* Tracking Demo */}
        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => navigation.navigate('Tracking', { orderType: 'purchase' })}
        >
          <Navigation color="#166534" size={20} />
          <Text style={styles.menuText}>{t('trackOrder')}</Text>
          <ChevronRight color="#94a3b8" size={18} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() =>
            Alert.alert('Helpline', 'Call support?', [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Call',
                onPress: () => Linking.openURL('tel:+911800000000'),
              },
            ])
          }
        >
          <Phone color="#166534" size={20} />
          <Text style={styles.menuText}>24×7 Helpline</Text>
          <ChevronRight color="#94a3b8" size={18} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => navigation.navigate('PrivacyPolicy')}
        >
          <Shield color="#166534" size={20} />
          <Text style={styles.menuText}>Privacy Policy</Text>
          <ChevronRight color="#94a3b8" size={18} />
        </TouchableOpacity>

        <TouchableOpacity style={[styles.menuItem, { marginTop: 20 }]} onPress={() => Alert.alert('Sign out', 'Are you sure you want to sign out?', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', style: 'destructive', onPress: async () => { await clearToken(); onLogout?.(); } }])}>
          <LogOut color="#dc2626" size={20} />
          <Text style={[styles.menuText, { color: '#dc2626' }]}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Language Selection Modal */}
      <Modal visible={langModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Language / भाषा चुनें</Text>
            <FlatList
              data={LANGUAGES}
              keyExtractor={(item) => item.code}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.langItem}
                  onPress={() => {
                    setLang(item.code as LangCode);
                    setLangModal(false);
                  }}
                >
                  <View>
                    <Text style={styles.langNative}>{item.native}</Text>
                    <Text style={styles.langName}>{item.name}</Text>
                  </View>
                  {lang === item.code && <Check color="#166534" size={22} />}
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setLangModal(false)}
            >
              <Text style={styles.closeBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    backgroundColor: '#166534',
    paddingTop: 30,
    paddingBottom: 24,
    alignItems: 'center',
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  name: { color: '#fff', fontSize: 20, fontWeight: '700' },
  location: { color: '#bbf7d0', fontSize: 13, marginTop: 4 },
  content: { padding: 16 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
  },
  cardTitle: { fontSize: 15, fontWeight: '700', color: '#1e293b', marginBottom: 8 },
  detail: { fontSize: 13, color: '#475569', marginBottom: 4 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    gap: 12,
  },
  menuText: { flex: 1, fontSize: 14, fontWeight: '600', color: '#1e293b' },
  menuSub: { fontSize: 12, color: '#64748b', marginTop: 2 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '70%',
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
    textAlign: 'center',
  },
  langItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  langNative: { fontSize: 16, fontWeight: '600', color: '#1e293b' },
  langName: { fontSize: 12, color: '#64748b', marginTop: 2 },
  closeBtn: {
    marginTop: 16,
    backgroundColor: '#f1f5f9',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  closeBtnText: { fontSize: 15, fontWeight: '600', color: '#475569' },
});
